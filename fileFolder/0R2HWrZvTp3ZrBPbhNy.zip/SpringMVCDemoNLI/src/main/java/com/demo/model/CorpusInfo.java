package com.demo.model;

import java.io.Serializable;
import javax.validation.constraints.Size;

public class CorpusInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Size(min=2, max=30)
	private String corpus;

	public String getCorpus() {
		return corpus;
	}

	public void setCorpus(String corpus) {
		this.corpus = corpus;
	}

	@Override
	public String toString() {
		return "";
	}
	
}

